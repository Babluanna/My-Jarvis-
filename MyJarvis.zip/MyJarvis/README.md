# MY JARVIS

Native Android assistant (Kotlin + Jetpack Compose, Material 3) with a small Node.js backend that holds your
Gemini / OpenRouter keys, chat history, memories and synced settings.

## 1. Run the backend
```
cd backend
cp .env.example .env      # fill in APP_ACCESS_CODE and at least one API key
npm install
set -a; . ./.env; set +a; npm start
```
Deploy it anywhere that gives you HTTPS (Cloud Run, Fly.io, Render, a VPS behind Caddy). A Dockerfile is included;
mount a volume at `/data` so history survives restarts. API keys live only in the server's environment.

## 2. Build the app
1. Open the project folder in Android Studio (Ladybug or newer). It creates the Gradle wrapper and syncs.
2. Set your server in `gradle.properties` (`backendUrl=https://your-server`). The default `http://10.0.2.2:8080` is for the emulator.
3. Run on a phone or emulator. In **Settings > Server** enter the Access code from `.env`, then tap Save.
4. For voice, install Google's speech services and Telugu/Hindi voice data (Android Settings > Language > Text-to-speech).

## How it works
- Every message goes to `/v1/chat`. The server asks the chosen model for one JSON object: reply, language, an optional
  phone action and an optional "remember" suggestion. The server validates the action against a fixed allow-list.
- The app shows a Confirm card before acting (default: every action; WhatsApp drafts and dialing always). In voice mode
  it asks aloud and listens for yes / no (Telugu, Hindi, English).
- Actions use plain intents and APIs: open apps, Settings screens, camera, flashlight, media volume, alarms (Clock app),
  reminders (AlarmManager + notification), links, dialer, WhatsApp draft (you press send).
- Web search: toggle "Web search" in chat (Gemini Google Search grounding, or OpenRouter `:online`).
- Images: the model proposes GENERATE_IMAGE; the server calls Gemini's image model (`IMAGE_MODEL`).
- Memory: Jarvis only suggests; nothing is saved until you tap Save. View/delete in Settings.
- Daily update: WorkManager, about 8:00, needs Notifications permission.

## Known limits (be aware)
- Android blocks apps from secretly controlling other apps or sending messages. Jarvis doesn't try; it hands off to the
  target app and you press send. No Accessibility permission is used.
- "Hey Jarvis" uses SpeechRecognizer in a loop: simple, but battery hungry and not instant. Android 10+ restricts
  starting activities from the background, so the wake word opens Jarvis reliably only if you allow
  "Display over other apps" (Settings > Permissions). For production swap in an on-device wake-word engine (e.g. Porcupine).
- Voice replies use the phone's built-in TTS voices. Quality depends on installed voices.
- Reminders use inexact alarms (can fire a few minutes late) and are not restored after a reboot.
- Model IDs change often. Edit `MODELS_JSON` on the server to match current Gemini / OpenRouter names.
- Release builds need your own signing config.
