package com.myjarvis

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.myjarvis.data.Api
import com.myjarvis.data.Prefs
import com.myjarvis.device.DeviceActions

class JarvisApplication : Application() {
    lateinit var prefs: Prefs
    lateinit var api: Api
    lateinit var actions: DeviceActions

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        api = Api(prefs)
        actions = DeviceActions(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_REMINDERS, "Reminders", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_DAILY, "Daily update", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_WAKE, "Wake word listening", NotificationManager.IMPORTANCE_LOW))
    }

    companion object {
        const val CH_REMINDERS = "reminders"
        const val CH_DAILY = "daily"
        const val CH_WAKE = "wake"
    }
}
