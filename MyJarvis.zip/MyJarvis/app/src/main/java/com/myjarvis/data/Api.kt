package com.myjarvis.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class ApiException(msg: String) : Exception(msg)

/** Talks ONLY to your own backend. The Gemini / OpenRouter keys never exist in the app. */
class Api(private val prefs: Prefs) {
    private val json = Json { ignoreUnknownKeys = true; explicitNulls = false; encodeDefaults = true }
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json".toMediaType()

    private fun request(s: Settings, method: String, path: String, body: String?, token: String?, code: String? = null): String {
        val rb = when {
            body != null -> body.toRequestBody(jsonType)
            method == "GET" || method == "DELETE" -> null
            else -> "".toRequestBody(jsonType)
        }
        val b = Request.Builder().url(s.backendUrl.trimEnd('/') + path).method(method, rb)
        token?.let { b.header("Authorization", "Bearer $it") }
        code?.let { b.header("x-access-code", it) }
        try {
            http.newCall(b.build()).execute().use { r ->
                val t = r.body?.string().orEmpty()
                if (!r.isSuccessful) {
                    val msg = runCatching { json.parseToJsonElement(t).jsonObject["error"]?.jsonPrimitive?.content }.getOrNull()
                    throw ApiException(if (r.code == 401 && token != null) "UNAUTHORIZED" else msg ?: "Server error ${r.code}")
                }
                return t
            }
        } catch (e: IOException) {
            throw ApiException("Can't reach the server. Check the server URL and your internet connection in Settings.")
        }
    }

    private suspend fun register(s: Settings): String {
        val body = request(s, "POST", "/v1/register", "{}", null, s.accessCode)
        val t = json.decodeFromString<TokenResp>(body).token
        prefs.set(K.token, t)
        return t
    }

    private suspend fun auth(method: String, path: String, body: String? = null): String = withContext(Dispatchers.IO) {
        val s = prefs.current()
        val token = s.token.ifBlank { register(s) }
        try {
            request(s, method, path, body, token)
        } catch (e: ApiException) {
            if (e.message == "UNAUTHORIZED") request(s, method, path, body, register(s)) else throw e
        }
    }

    suspend fun chat(r: ChatReq): ChatReply = json.decodeFromString(auth("POST", "/v1/chat", json.encodeToString(r)))
    suspend fun history(): List<HistoryItem> = json.decodeFromString(auth("GET", "/v1/history"))
    suspend fun clearHistory() { auth("DELETE", "/v1/history") }
    suspend fun models(): List<ModelInfo> = json.decodeFromString(auth("GET", "/v1/models"))
    suspend fun memories(): List<Memory> = json.decodeFromString(auth("GET", "/v1/memories"))
    suspend fun addMemory(t: String) { auth("POST", "/v1/memories", json.encodeToString(mapOf("text" to t))) }
    suspend fun deleteMemory(id: Long) { auth("DELETE", "/v1/memories/$id") }
    suspend fun image(prompt: String): ImageResp =
        json.decodeFromString(auth("POST", "/v1/image", json.encodeToString(mapOf("prompt" to prompt))))
    suspend fun daily(lang: String, now: String): DailyResp {
        val q = "lang=${URLEncoder.encode(lang, "UTF-8")}&now=${URLEncoder.encode(now, "UTF-8")}"
        return json.decodeFromString(auth("GET", "/v1/daily?$q"))
    }
    suspend fun getSettings(): Map<String, String> = json.decodeFromString(auth("GET", "/v1/settings"))
    suspend fun putSettings(m: Map<String, String>) { auth("PUT", "/v1/settings", json.encodeToString(m)) }
}
