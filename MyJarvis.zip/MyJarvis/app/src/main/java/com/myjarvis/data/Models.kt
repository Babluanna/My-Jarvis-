package com.myjarvis.data

import kotlinx.serialization.Serializable

/** One phone action proposed by the AI. Only the fields relevant to [type] are set. */
@Serializable
data class ActionDto(
    val type: String,
    val app: String? = null,
    val setting: String? = null,
    val level: Int? = null,
    val on: Boolean? = null,
    val hour: Int? = null,
    val minute: Int? = null,
    val text: String? = null,
    val at: String? = null,
    val url: String? = null,
    val number: String? = null,
)

@Serializable
data class ChatReply(
    val reply: String,
    val lang: String? = null,
    val action: ActionDto? = null,
    val remember: String? = null,
)

@Serializable
data class ChatReq(
    val provider: String,
    val model: String,
    val message: String,
    val language: String,
    val now: String,
    val search: Boolean,
)

@Serializable data class HistoryItem(val role: String, val content: String, val ts: Long = 0)
@Serializable data class ModelInfo(val provider: String, val id: String, val label: String)
@Serializable data class Memory(val id: Long, val text: String)
@Serializable data class ImageResp(val mime: String, val data: String)
@Serializable data class DailyResp(val text: String)
@Serializable data class TokenResp(val token: String)
