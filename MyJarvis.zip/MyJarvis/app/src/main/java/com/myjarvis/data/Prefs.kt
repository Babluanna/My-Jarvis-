package com.myjarvis.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.myjarvis.BuildConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.ds by preferencesDataStore("jarvis")

object K {
    val url = stringPreferencesKey("url")
    val code = stringPreferencesKey("code")
    val token = stringPreferencesKey("token")
    val provider = stringPreferencesKey("provider")
    val model = stringPreferencesKey("model")
    val language = stringPreferencesKey("language")
    val speak = booleanPreferencesKey("speak")
    val confirmAll = booleanPreferencesKey("confirmAll")
    val wake = booleanPreferencesKey("wake")
    val daily = booleanPreferencesKey("daily")
    val theme = stringPreferencesKey("theme")
}

data class Settings(
    val backendUrl: String,
    val accessCode: String,
    val token: String,
    val provider: String,
    val model: String,
    val language: String,   // speech recognition locale: te-IN, en-IN, hi-IN
    val speak: Boolean,     // read chat replies aloud (voice mode always speaks)
    val confirmAll: Boolean,// ask before every phone action
    val wakeWord: Boolean,
    val daily: Boolean,
    val theme: String,      // system | light | dark
)

class Prefs(private val ctx: Context) {
    val flow: Flow<Settings> = ctx.ds.data.map { p ->
        Settings(
            backendUrl = p[K.url] ?: BuildConfig.BACKEND_URL,
            accessCode = p[K.code] ?: "",
            token = p[K.token] ?: "",
            provider = p[K.provider] ?: "gemini",
            model = p[K.model] ?: "gemini-2.5-flash",
            language = p[K.language] ?: "te-IN",
            speak = p[K.speak] ?: false,
            confirmAll = p[K.confirmAll] ?: true,
            wakeWord = p[K.wake] ?: false,
            daily = p[K.daily] ?: false,
            theme = p[K.theme] ?: "system",
        )
    }

    suspend fun current(): Settings = flow.first()

    suspend fun <T> set(key: Preferences.Key<T>, v: T) {
        ctx.ds.edit { it[key] = v }
    }

    /** Settings that are synchronised through the backend (not server URL, token or wake word). */
    suspend fun syncBlob(): Map<String, String> {
        val s = current()
        return mapOf(
            "provider" to s.provider, "model" to s.model, "language" to s.language,
            "speak" to s.speak.toString(), "confirmAll" to s.confirmAll.toString(),
            "daily" to s.daily.toString(), "theme" to s.theme,
        )
    }

    suspend fun applyBlob(m: Map<String, String>) {
        ctx.ds.edit { p ->
            m["provider"]?.let { v -> p[K.provider] = v }
            m["model"]?.let { v -> p[K.model] = v }
            m["language"]?.let { v -> p[K.language] = v }
            m["speak"]?.let { v -> p[K.speak] = v == "true" }
            m["confirmAll"]?.let { v -> p[K.confirmAll] = v == "true" }
            m["daily"]?.let { v -> p[K.daily] = v == "true" }
            m["theme"]?.let { v -> p[K.theme] = v }
        }
    }
}
