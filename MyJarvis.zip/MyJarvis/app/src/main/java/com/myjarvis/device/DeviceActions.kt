package com.myjarvis.device

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import com.myjarvis.data.ActionDto
import com.myjarvis.work.ReminderReceiver
import java.net.URLEncoder
import java.time.LocalDateTime
import java.time.ZoneId

/** Performs user-authorised phone actions using normal Android intents and APIs. No hidden control. */
class DeviceActions(private val ctx: Context) {
    private var torchOn = false

    fun isSensitive(a: ActionDto) = a.type == "WHATSAPP_DRAFT" || a.type == "DIAL"

    /** Actions that move the user to another app (voice session ends afterwards). */
    fun leavesApp(a: ActionDto) =
        a.type in setOf("OPEN_APP", "OPEN_SETTINGS", "OPEN_CAMERA", "OPEN_URL", "WHATSAPP_DRAFT", "DIAL")

    fun describe(a: ActionDto): String = when (a.type) {
        "OPEN_APP" -> "Open ${a.app}"
        "OPEN_SETTINGS" -> "Open ${a.setting ?: "phone"} settings"
        "OPEN_CAMERA" -> "Open the camera"
        "FLASHLIGHT" -> "Turn the flashlight ${if (a.on == false) "off" else "on"}"
        "VOLUME" -> if (a.level != null) "Set media volume to ${a.level}%" else "Turn the volume ${a.text ?: "up"}"
        "SET_ALARM" -> "Set an alarm for %02d:%02d".format(a.hour ?: 0, a.minute ?: 0) + (a.text?.let { " ($it)" } ?: "")
        "SET_REMINDER" -> "Remind you: ${a.text} (${a.at})"
        "OPEN_URL" -> "Open ${a.url}"
        "DIAL" -> "Open the dialer with ${a.number} (you press call)"
        "WHATSAPP_DRAFT" -> "Draft a WhatsApp message: \"${a.text}\" (you choose the contact and press send)"
        "GENERATE_IMAGE" -> "Generate an image: ${a.text}"
        else -> "Unknown action"
    }

    fun execute(a: ActionDto): String = try {
        when (a.type) {
            "OPEN_APP" -> openApp(a.app ?: "")
            "OPEN_SETTINGS" -> openSettings(a.setting ?: "")
            "OPEN_CAMERA" -> { start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); "✓ Camera opened" }
            "FLASHLIGHT" -> flashlight(a.on)
            "VOLUME" -> volume(a)
            "SET_ALARM" -> alarm(a)
            "SET_REMINDER" -> reminder(a)
            "OPEN_URL" -> openUrl(a.url ?: "")
            "DIAL" -> { start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(a.number ?: "")))); "✓ Dialer opened" }
            "WHATSAPP_DRAFT" -> {
                val u = "https://wa.me/?text=" + URLEncoder.encode(a.text ?: "", "UTF-8")
                start(Intent(Intent.ACTION_VIEW, Uri.parse(u)).setPackage("com.whatsapp"))
                "✓ WhatsApp opened with your draft. Choose a contact and press send yourself."
            }
            else -> "I can't do that action."
        }
    } catch (e: ActivityNotFoundException) {
        "That app or screen isn't available on this phone."
    } catch (e: Exception) {
        "Couldn't do that: ${e.message}"
    }

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private val knownApps = mapOf(
        "youtube" to "com.google.android.youtube", "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android", "chrome" to "com.android.chrome",
        "maps" to "com.google.android.apps.maps", "google maps" to "com.google.android.apps.maps",
        "gmail" to "com.google.android.gm", "facebook" to "com.facebook.katana",
        "telegram" to "org.telegram.messenger", "spotify" to "com.spotify.music",
    )

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val q = name.lowercase().trim()
        if (q.isEmpty()) return "Which app?"
        var pkg = knownApps[q]?.takeIf { pm.getLaunchIntentForPackage(it) != null }
        if (pkg == null) {
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            pkg = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }?.activityInfo?.packageName
                ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }?.activityInfo?.packageName
        }
        val launch = pkg?.let { pm.getLaunchIntentForPackage(it) }
        return if (launch != null) {
            start(launch); "✓ Opened $name"
        } else {
            start(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(name))))
            "$name isn't installed. Opened the Play Store search."
        }
    }

    private fun openSettings(which: String): String {
        val action = when (which.lowercase()) {
            "wifi", "wi-fi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display", "brightness" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound", "volume" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        start(Intent(action)); return "✓ Settings opened"
    }

    private fun flashlight(on: Boolean?): String {
        val cm = ctx.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "This phone has no flashlight."
        torchOn = on ?: !torchOn
        cm.setTorchMode(id, torchOn)
        return if (torchOn) "✓ Flashlight on" else "✓ Flashlight off"
    }

    private fun volume(a: ActionDto): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        val stream = AudioManager.STREAM_MUSIC
        if (a.level != null) {
            val max = am.getStreamMaxVolume(stream)
            am.setStreamVolume(stream, (max * a.level.coerceIn(0, 100) / 100f).toInt(), AudioManager.FLAG_SHOW_UI)
            return "✓ Volume set to ${a.level.coerceIn(0, 100)}%"
        }
        val dir = if (a.text == "down") AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE
        am.adjustStreamVolume(stream, dir, AudioManager.FLAG_SHOW_UI)
        return "✓ Volume ${if (a.text == "down") "lowered" else "raised"}"
    }

    private fun alarm(a: ActionDto): String {
        val h = a.hour ?: return "I need a time for the alarm."
        val m = a.minute ?: 0
        start(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.text ?: "Jarvis alarm")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return "✓ Alarm set for %02d:%02d".format(h, m)
    }

    private fun reminder(a: ActionDto): String {
        val text = a.text ?: "Reminder"
        val at = a.at ?: return "I need a date and time for the reminder."
        val whenMs = LocalDateTime.parse(at.substringBefore('+').substringBefore('Z').take(19))
            .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (whenMs <= System.currentTimeMillis()) return "That time has already passed."
        val am = ctx.getSystemService(AlarmManager::class.java)
        val i = Intent(ctx, ReminderReceiver::class.java).putExtra("text", text).putExtra("id", whenMs)
        val pi = PendingIntent.getBroadcast(
            ctx, (whenMs % Int.MAX_VALUE).toInt(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        // Inexact-while-idle: needs no special permission, may fire a few minutes late.
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
        return "✓ Reminder set: $text"
    }

    private fun openUrl(url: String): String {
        if (!url.startsWith("https://") && !url.startsWith("http://")) return "Only web links can be opened."
        start(Intent(Intent.ACTION_VIEW, Uri.parse(url))); return "✓ Link opened"
    }
}
