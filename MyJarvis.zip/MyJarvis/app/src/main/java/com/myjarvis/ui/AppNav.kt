package com.myjarvis.ui

import androidx.compose.runtime.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

@Composable
fun AppNav(vm: ChatViewModel) {
    val nav = rememberNavController()
    val requested by vm.voiceRequested.collectAsState()
    LaunchedEffect(requested) {
        if (requested) {
            vm.voiceRequested.value = false
            nav.navigate("voice") { launchSingleTop = true }
        }
    }
    NavHost(nav, startDestination = "chat") {
        composable("chat") {
            ChatScreen(vm, onVoice = { nav.navigate("voice") }, onSettings = { nav.navigate("settings") })
        }
        composable("voice") { VoiceScreen(vm, onClose = { nav.popBackStack() }) }
        composable("settings") { SettingsScreen(vm, onBack = { nav.popBackStack() }) }
    }
}
