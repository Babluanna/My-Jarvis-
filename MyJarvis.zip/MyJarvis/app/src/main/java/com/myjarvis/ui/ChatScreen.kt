package com.myjarvis.ui

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.myjarvis.data.ActionDto

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel, onVoice: () -> Unit, onSettings: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val st by vm.settings.collectAsState()
    val models by vm.models.collectAsState()
    var input by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val list = rememberLazyListState()
    LaunchedEffect(ui.messages.size) {
        if (ui.messages.isNotEmpty()) list.scrollToItem(ui.messages.lastIndex)
    }
    val modelLabel = models.firstOrNull { it.id == st?.model }?.label ?: st?.model ?: ""

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Jarvis") },
                actions = {
                    Box {
                        TextButton(onClick = { menu = true }) {
                            Text(modelLabel, maxLines = 1)
                            Icon(Icons.Filled.ArrowDropDown, contentDescription = "Switch model")
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            models.forEach { m ->
                                DropdownMenuItem(
                                    text = { Text(m.label) },
                                    onClick = { menu = false; vm.setModel(m) },
                                )
                            }
                        }
                    }
                    IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, contentDescription = "Settings") }
                },
            )
        },
    ) { inner ->
        Column(
            Modifier.padding(inner).consumeWindowInsets(inner).imePadding().fillMaxSize()
        ) {
            if (ui.messages.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Ask me anything in Telugu, Hindi or English.\nTap the mic to talk.",
                        textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(), state = list,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) { items(ui.messages, key = { it.id }) { MessageRow(it) } }
            }

            ui.pendingAction?.let { ActionCard(vm.describe(it), onConfirm = vm::confirmAction, onCancel = vm::dismissAction) }
            ui.pendingMemory?.let { MemoryCard(it, onSave = vm::approveMemory, onSkip = vm::dismissMemory) }
            ui.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            }

            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = ui.searchOn, onClick = vm::toggleSearch, label = { Text("Web search") })
                Spacer(Modifier.width(12.dp))
                if (ui.busy) Text("Thinking…", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                    placeholder = { Text("Message") }, shape = RoundedCornerShape(24.dp), maxLines = 4,
                )
                Spacer(Modifier.width(8.dp))
                if (input.isBlank()) {
                    FilledTonalIconButton(onClick = onVoice) { Icon(Icons.Filled.Mic, contentDescription = "Voice conversation") }
                } else {
                    FilledIconButton(onClick = { vm.send(input); input = "" }) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageRow(m: UiMsg) {
    if (m.role == "note") {
        Text(
            m.text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        )
        return
    }
    val user = m.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (user) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 320.dp),
        ) {
            Column(Modifier.padding(12.dp)) {
                m.image?.let { b64 ->
                    val bmp = remember(b64) {
                        runCatching {
                            val bytes = Base64.decode(b64, Base64.DEFAULT)
                            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        }.getOrNull()
                    }
                    bmp?.let { Image(it.asImageBitmap(), contentDescription = "Generated image", modifier = Modifier.fillMaxWidth()) }
                }
                if (m.text.isNotBlank()) Text(m.text)
            }
        }
    }
}

@Composable
fun ActionCard(description: String, onConfirm: () -> Unit, onCancel: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("Jarvis wants to:", style = MaterialTheme.typography.labelMedium)
            Text(description, style = MaterialTheme.typography.bodyLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onCancel) { Text("Cancel") }
                Button(onClick = onConfirm) { Text("Confirm") }
            }
        }
    }
}

@Composable
private fun MemoryCard(text: String, onSave: () -> Unit, onSkip: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("Save to memory?", style = MaterialTheme.typography.labelMedium)
            Text(text)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onSkip) { Text("No") }
                Button(onClick = onSave) { Text("Save") }
            }
        }
    }
}
