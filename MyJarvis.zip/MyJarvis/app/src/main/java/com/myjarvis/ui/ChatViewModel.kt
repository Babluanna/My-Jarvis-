package com.myjarvis.ui

import android.app.Application
import android.content.Intent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.myjarvis.JarvisApplication
import com.myjarvis.data.*
import com.myjarvis.voice.*
import com.myjarvis.work.DailyUpdateWorker
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.time.OffsetDateTime
import java.util.Locale

data class UiMsg(val id: Long, val role: String, val text: String, val image: String? = null)
enum class VoiceState { Idle, Listening, Thinking, Speaking }

data class UiState(
    val messages: List<UiMsg> = emptyList(),
    val busy: Boolean = false,
    val error: String? = null,
    val searchOn: Boolean = false,
    val pendingAction: ActionDto? = null,
    val pendingMemory: String? = null,
    val voiceActive: Boolean = false,
    val voiceState: VoiceState = VoiceState.Idle,
    val transcript: String = "",
    val lastReply: String = "",
)

private val fallbackModels = listOf(
    ModelInfo("gemini", "gemini-2.5-flash", "Gemini 2.5 Flash"),
    ModelInfo("gemini", "gemini-2.5-pro", "Gemini 2.5 Pro"),
    ModelInfo("openrouter", "openai/gpt-4o-mini", "GPT-4o mini (OpenRouter)"),
)

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as JarvisApplication
    private val voice = VoiceInput(app)
    private val speaker = Speaker(app)

    val settings: StateFlow<Settings?> = a.prefs.flow.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    private val _ui = MutableStateFlow(UiState())
    val ui = _ui.asStateFlow()
    private val _models = MutableStateFlow(fallbackModels)
    val models = _models.asStateFlow()
    private val _memories = MutableStateFlow<List<Memory>>(emptyList())
    val memories = _memories.asStateFlow()
    val voiceRequested = MutableStateFlow(false)

    private var nextId = 0L
    private var voiceJob: Job? = null
    private var leftApp = false

    init {
        viewModelScope.launch {
            runCatching { a.prefs.applyBlob(a.api.getSettings()) }
            runCatching { _models.value = a.api.models() }
            runCatching {
                if (_ui.value.messages.isEmpty()) {
                    val h = a.api.history().filter { it.role == "user" || it.role == "assistant" }
                    _ui.update { st -> st.copy(messages = h.map { UiMsg(nextId++, it.role, it.content) }) }
                }
            }
            val s = a.prefs.current()
            DailyUpdateWorker.schedule(a, s.daily)
        }
    }

    private fun upd(f: (UiState) -> UiState) = _ui.update(f)
    private fun addMsg(role: String, text: String, image: String? = null) =
        upd { it.copy(messages = it.messages + UiMsg(nextId++, role, text, image)) }
    private fun setVs(v: VoiceState) = upd { it.copy(voiceState = v) }

    fun describe(a2: ActionDto) = a.actions.describe(a2)
    fun toggleSearch() = upd { it.copy(searchOn = !it.searchOn) }
    fun dismissError() = upd { it.copy(error = null) }

    // ---------- chat ----------
    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || _ui.value.busy) return
        viewModelScope.launch {
            val r = ask(t)
            val s = a.prefs.current()
            if (r != null && s.speak) speaker.speak(r.reply, localeFor(r.lang, s.language))
        }
    }

    private suspend fun ask(t: String): ChatReply? {
        addMsg("user", t)
        upd { it.copy(busy = true, error = null) }
        return try {
            val s = a.prefs.current()
            val r = a.api.chat(ChatReq(s.provider, s.model, t, s.language, OffsetDateTime.now().toString(), _ui.value.searchOn))
            addMsg("assistant", r.reply)
            handle(r, s)
            r
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            upd { it.copy(error = e.message ?: "Something went wrong") }
            null
        } finally {
            upd { it.copy(busy = false) }
        }
    }

    private suspend fun handle(r: ChatReply, s: Settings) {
        r.remember?.takeIf { it.isNotBlank() }?.let { m -> upd { it.copy(pendingMemory = m) } }
        val act = r.action ?: return
        if (act.type == "NONE") return
        if (s.confirmAll || a.actions.isSensitive(act)) upd { it.copy(pendingAction = act) } else runAction(act)
    }

    private suspend fun runAction(act: ActionDto) {
        if (act.type == "GENERATE_IMAGE") {
            val p = act.text ?: return
            addMsg("note", "Generating image…")
            try { addMsg("assistant", "", a.api.image(p).data) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { addMsg("note", "Image failed: ${e.message}") }
        } else {
            addMsg("note", a.actions.execute(act))
            if (a.actions.leavesApp(act)) leftApp = true
        }
    }

    fun confirmAction() {
        val p = _ui.value.pendingAction ?: return
        upd { it.copy(pendingAction = null) }
        viewModelScope.launch { runAction(p) }
    }

    fun dismissAction() {
        upd { it.copy(pendingAction = null) }
        addMsg("note", "Cancelled")
    }

    fun approveMemory() {
        val m = _ui.value.pendingMemory ?: return
        upd { it.copy(pendingMemory = null) }
        viewModelScope.launch {
            runCatching { a.api.addMemory(m) }.onSuccess { addMsg("note", "Saved to memory") }
                .onFailure { upd { st -> st.copy(error = it.message) } }
        }
    }

    fun dismissMemory() = upd { it.copy(pendingMemory = null) }

    // ---------- voice conversation ----------
    fun startVoice() {
        if (voiceJob?.isActive == true) return
        voiceJob = viewModelScope.launch {
            VoiceLock.appListening = true
            leftApp = false
            upd { it.copy(voiceActive = true, transcript = "", lastReply = "", error = null) }
            var misses = 0
            try {
                while (isActive) {
                    val s = a.prefs.current()
                    setVs(VoiceState.Listening)
                    val heard = voice.listen(s.language) { p -> upd { it.copy(transcript = p) } }
                    if (heard == null) {
                        val soft = voice.lastError == SpeechRecognizer.ERROR_NO_MATCH ||
                            voice.lastError == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                        if (soft && ++misses < 3) continue
                        if (!soft) upd { it.copy(error = "Voice recognition isn't available right now (code ${voice.lastError}).") }
                        break
                    }
                    misses = 0
                    upd { it.copy(transcript = heard) }
                    if (isStop(heard)) break
                    setVs(VoiceState.Thinking)
                    val r = ask(heard) ?: break
                    upd { it.copy(lastReply = r.reply) }
                    setVs(VoiceState.Speaking)
                    speaker.speak(r.reply, localeFor(r.lang, s.language))
                    val pa = _ui.value.pendingAction
                    if (pa != null) {
                        upd { it.copy(lastReply = a.actions.describe(pa)) }
                        speaker.speak(confirmPrompt(r.lang), localeFor(r.lang, s.language))
                        setVs(VoiceState.Listening)
                        val ans = voice.listen(s.language) { }
                        if (ans != null && isYes(ans)) {
                            upd { it.copy(pendingAction = null) }
                            runAction(pa)
                        } else dismissAction()
                    }
                    if (leftApp) break // another app is in front; the mic can't be used from the background
                }
            } finally {
                VoiceLock.appListening = false
                upd { it.copy(voiceActive = false, voiceState = VoiceState.Idle) }
                speaker.stop()
            }
        }
    }

    fun stopVoice() {
        voiceJob?.cancel()
        speaker.stop()
    }

    private fun localeFor(lang: String?, fallback: String): Locale = when (lang) {
        "te" -> Locale("te", "IN")
        "hi" -> Locale("hi", "IN")
        "en" -> Locale("en", "IN")
        else -> Locale.forLanguageTag(fallback)
    }

    private fun confirmPrompt(lang: String?) = when (lang) {
        "te" -> "ఇది చేయమంటారా?"
        "hi" -> "क्या मैं यह करूँ?"
        else -> "Shall I go ahead?"
    }

    private val yesWords = listOf(
        "yes", "yeah", "yep", "ok", "okay", "sure", "go ahead", "do it", "please", "avunu", "sare", "haa", "ha ",
        "అవును", "సరే", "చేయి", "చెయ్యి", "హా", "అలాగే", "हाँ", "हां", "ठीक", "करो", "जी",
    )
    private val stopWords = listOf("stop", "bye", "goodbye", "that's all", "ఆపు", "చాలు", "బై", "बंद", "रुको", "बस", "अलविदा")
    private fun isYes(t: String) = t.lowercase().let { s -> yesWords.any { it in s } }
    private fun isStop(t: String) = t.lowercase().let { s -> stopWords.any { it in s } }

    // ---------- settings ----------
    fun <T> setPref(key: Preferences.Key<T>, v: T, sync: Boolean = true) {
        viewModelScope.launch {
            a.prefs.set(key, v)
            if (sync) pushSettings()
        }
    }

    fun setModel(m: ModelInfo) {
        viewModelScope.launch {
            a.prefs.set(K.provider, m.provider)
            a.prefs.set(K.model, m.id)
            pushSettings()
        }
    }

    fun setServer(url: String, code: String) {
        viewModelScope.launch {
            a.prefs.set(K.url, url.trim())
            a.prefs.set(K.code, code.trim())
            a.prefs.set(K.token, "")
            runCatching { _models.value = a.api.models() }.onFailure { upd { st -> st.copy(error = it.message) } }
        }
    }

    fun setWake(on: Boolean) {
        viewModelScope.launch { a.prefs.set(K.wake, on) }
        val i = Intent(a, WakeWordService::class.java)
        if (on) ContextCompat.startForegroundService(a, i) else a.stopService(i)
    }

    fun setDaily(on: Boolean) {
        viewModelScope.launch { a.prefs.set(K.daily, on); pushSettings() }
        DailyUpdateWorker.schedule(a, on)
    }

    private fun pushSettings() {
        viewModelScope.launch { runCatching { a.api.putSettings(a.prefs.syncBlob()) } }
    }

    fun loadMemories() {
        viewModelScope.launch { runCatching { _memories.value = a.api.memories() } }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            runCatching { a.api.deleteMemory(id) }
            loadMemories()
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            runCatching { a.api.clearHistory() }.onFailure { upd { st -> st.copy(error = it.message) } }
            upd { it.copy(messages = emptyList()) }
        }
    }

    override fun onCleared() {
        voiceJob?.cancel()
        speaker.shutdown()
        super.onCleared()
    }
}
