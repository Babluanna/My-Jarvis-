package com.myjarvis.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.myjarvis.data.K

private fun granted(c: android.content.Context, p: String) =
    ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val st by vm.settings.collectAsState()
    val s = st ?: return
    val models by vm.models.collectAsState()
    val memories by vm.memories.collectAsState()
    val ctx = LocalContext.current

    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    val micOk = remember(tick) { granted(ctx, Manifest.permission.RECORD_AUDIO) }
    val notifOk = remember(tick) { Build.VERSION.SDK_INT < 33 || granted(ctx, Manifest.permission.POST_NOTIFICATIONS) }
    val overlayOk = remember(tick) { AndroidSettings.canDrawOverlays(ctx) }

    var wakePending by remember { mutableStateOf(false) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        tick++
        if (ok && wakePending) vm.setWake(true)
        wakePending = false
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    var urlText by remember(s.backendUrl) { mutableStateOf(s.backendUrl) }
    var codeText by remember(s.accessCode) { mutableStateOf(s.accessCode) }
    var confirmClear by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.loadMemories() }

    val langs = listOf("Telugu (తెలుగు)" to "te-IN", "English (India)" to "en-IN", "Hindi (हिन्दी)" to "hi-IN")
    val themes = listOf("System" to "system", "Light" to "light", "Dark" to "dark")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
            )
        },
    ) { inner ->
        LazyColumn(
            Modifier.padding(inner).fillMaxSize(), contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { Section("AI model") }
            item {
                DropdownRow("Model", models.firstOrNull { it.id == s.model }?.label ?: s.model,
                    models.map { it.label to it }) { vm.setModel(it) }
            }
            item { Hint("Switch any time. The same choice is also in the top bar of the chat.") }

            item { Section("Language") }
            item {
                DropdownRow("Voice language", langs.firstOrNull { it.second == s.language }?.first ?: s.language, langs) {
                    vm.setPref(K.language, it)
                }
            }
            item { Hint("Jarvis replies in the language you speak or type, including Telugu and Hindi.") }

            item { Section("Voice") }
            item {
                SwitchRow("Read chat replies aloud", "Voice conversations always speak.", s.speak) { vm.setPref(K.speak, it) }
            }
            item {
                SwitchRow(
                    "“Hey Jarvis” wake word",
                    "Optional. Keeps the microphone listening with a visible notification. Uses more battery. Off by default.",
                    s.wakeWord,
                ) { on ->
                    if (!on) vm.setWake(false)
                    else if (micOk) vm.setWake(true)
                    else { wakePending = true; micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
                }
            }

            item { Section("Phone actions") }
            item {
                SwitchRow("Ask before every action", "When off, only sensitive actions (WhatsApp drafts, dialing) still need your OK.", s.confirmAll) {
                    vm.setPref(K.confirmAll, it)
                }
            }

            item { Section("Daily update") }
            item { SwitchRow("Morning briefing at 8:00", "A short notification with today’s headlines.", s.daily) { vm.setDaily(it) } }

            item { Section("Appearance") }
            item {
                DropdownRow("Theme", themes.firstOrNull { it.second == s.theme }?.first ?: "System", themes) { vm.setPref(K.theme, it) }
            }

            item { Section("Permissions") }
            item {
                PermissionRow("Microphone", "Needed to hear your voice commands.", micOk, "Allow") {
                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
            item {
                PermissionRow("Notifications", "Needed for reminders and the daily update.", notifOk, "Allow") {
                    if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            item {
                PermissionRow("Display over other apps", "Optional. Lets “Hey Jarvis” open Jarvis while another app is on screen.", overlayOk, "Open") {
                    ctx.startActivity(
                        Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    )
                }
            }
            item { Hint("Accessibility access is not used. Jarvis only uses normal Android intents, so it can’t secretly control other apps.") }

            item { Section("Memory") }
            if (memories.isEmpty()) item { Hint("Nothing saved. Jarvis only saves things after you approve them.") }
            items(memories, key = { it.id }) { m ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(m.text, Modifier.weight(1f))
                    IconButton(onClick = { vm.deleteMemory(m.id) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                }
            }

            item { Section("Server") }
            item {
                OutlinedTextField(urlText, { urlText = it }, label = { Text("Server URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            item {
                OutlinedTextField(codeText, { codeText = it }, label = { Text("Access code") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            item { Button(onClick = { vm.setServer(urlText, codeText) }) { Text("Save and reconnect") } }
            item { Hint("API keys stay on your server. This app never contains them.") }

            item { Section("Data") }
            item { OutlinedButton(onClick = { confirmClear = true }) { Text("Clear conversation history") } }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear history?") },
            text = { Text("This deletes your saved conversation from the server and this phone. Saved memories are kept.") },
            confirmButton = { TextButton(onClick = { confirmClear = false; vm.clearHistory() }) { Text("Clear") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
}

@Composable private fun Section(t: String) =
    Text(t, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 12.dp))

@Composable private fun Hint(t: String) =
    Text(t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun PermissionRow(title: String, why: String, ok: Boolean, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text("$title · ${if (ok) "Allowed" else "Not allowed"}")
            Text(why, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (!ok) OutlinedButton(onClick = onClick) { Text(action) }
    }
}

@Composable
private fun <T> DropdownRow(label: String, value: String, options: List<Pair<String, T>>, onPick: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: $value", Modifier.weight(1f), maxLines = 1)
            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (text, v) -> DropdownMenuItem(text = { Text(text) }, onClick = { open = false; onPick(v) }) }
        }
    }
}
