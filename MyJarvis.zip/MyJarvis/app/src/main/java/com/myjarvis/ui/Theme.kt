package com.myjarvis.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Light = lightColorScheme(
    primary = Color(0xFF1B5FC1), onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE7FA), onPrimaryContainer = Color(0xFF0B2A5B),
    background = Color.White, surface = Color.White, surfaceVariant = Color(0xFFF1F3F7),
    onSurface = Color(0xFF1B1D21), onSurfaceVariant = Color(0xFF5B6068), outlineVariant = Color(0xFFDDE1E7),
)
private val Dark = darkColorScheme(
    primary = Color(0xFF9CC0FF), onPrimary = Color(0xFF002E6A),
    primaryContainer = Color(0xFF1F3F73), onPrimaryContainer = Color(0xFFDCE7FA),
    background = Color(0xFF111316), surface = Color(0xFF111316), surfaceVariant = Color(0xFF22262B),
    onSurface = Color(0xFFE4E6EA), onSurfaceVariant = Color(0xFFA9AEB6), outlineVariant = Color(0xFF3A3F46),
)

@Composable
fun JarvisTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
