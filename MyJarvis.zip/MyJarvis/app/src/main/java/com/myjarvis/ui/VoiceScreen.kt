package com.myjarvis.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceScreen(vm: ChatViewModel, onClose: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    var showRationale by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
        if (it) vm.startVoice()
    }
    LaunchedEffect(Unit) { if (granted) vm.startVoice() else showRationale = true }
    DisposableEffect(Unit) { onDispose { vm.stopVoice() } }

    if (showRationale && !granted) {
        AlertDialog(
            onDismissRequest = { showRationale = false },
            title = { Text("Microphone access") },
            text = { Text("Jarvis needs the microphone to hear your voice commands. Audio is turned into text by your phone's speech service, and only that text is sent to your Jarvis server. You can switch listening off at any time.") },
            confirmButton = { TextButton(onClick = { showRationale = false; launcher.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Continue") } },
            dismissButton = { TextButton(onClick = { showRationale = false }) { Text("Not now") } },
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Voice") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
            )
        },
    ) { inner ->
        Column(
            Modifier.padding(inner).fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(24.dp))
            Text(
                when (ui.voiceState) {
                    VoiceState.Listening -> "Listening…"
                    VoiceState.Thinking -> "Thinking…"
                    VoiceState.Speaking -> "Speaking…"
                    VoiceState.Idle -> "Tap the microphone to talk"
                },
                style = MaterialTheme.typography.headlineSmall,
            )
            Spacer(Modifier.height(16.dp))
            if (ui.transcript.isNotBlank()) {
                Text("“${ui.transcript}”", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(16.dp))
            }
            if (ui.lastReply.isNotBlank()) Text(ui.lastReply, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyLarge)
            ui.error?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.weight(1f))
            ui.pendingAction?.let {
                ActionCard(vm.describe(it), onConfirm = vm::confirmAction, onCancel = vm::dismissAction)
                Spacer(Modifier.height(8.dp))
                Text("You can also just say yes or no.", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(24.dp))
            FilledIconButton(
                onClick = {
                    when {
                        ui.voiceActive -> vm.stopVoice()
                        granted -> vm.startVoice()
                        else -> showRationale = true
                    }
                },
                modifier = Modifier.size(84.dp),
            ) {
                Icon(
                    if (ui.voiceActive) Icons.Filled.Stop else Icons.Filled.Mic,
                    contentDescription = if (ui.voiceActive) "Stop" else "Start listening",
                    modifier = Modifier.size(36.dp),
                )
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
