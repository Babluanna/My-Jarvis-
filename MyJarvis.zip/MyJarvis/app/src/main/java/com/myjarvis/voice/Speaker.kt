package com.myjarvis.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/** Text to speech using the phone's installed voices (install Telugu/Hindi voice data in system TTS settings). */
class Speaker(ctx: Context) {
    private var ready = false
    private val tts: TextToSpeech = TextToSpeech(ctx.applicationContext) { ready = it == TextToSpeech.SUCCESS }

    suspend fun speak(text: String, locale: Locale) = suspendCancellableCoroutine<Unit> { cont ->
        if (!ready || text.isBlank()) { cont.resume(Unit); return@suspendCancellableCoroutine }
        val id = UUID.randomUUID().toString()
        tts.language = locale
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onDone(u: String?) { if (u == id && cont.isActive) cont.resume(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(u: String?) { if (u == id && cont.isActive) cont.resume(Unit) }
            override fun onError(u: String?, code: Int) { if (u == id && cont.isActive) cont.resume(Unit) }
        })
        cont.invokeOnCancellation { tts.stop() }
        tts.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun stop() { tts.stop() }
    fun shutdown() { tts.stop(); tts.shutdown() }
}
