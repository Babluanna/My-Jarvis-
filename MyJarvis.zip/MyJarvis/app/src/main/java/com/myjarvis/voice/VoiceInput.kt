package com.myjarvis.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Speech to text using Android's SpeechRecognizer (Telugu: te-IN, Hindi: hi-IN, English: en-IN). */
class VoiceInput(private val ctx: Context) {
    @Volatile var lastError = 0

    suspend fun listen(lang: String, onPartial: (String) -> Unit): String? = suspendCancellableCoroutine { cont ->
        lastError = 0
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            lastError = -1
            cont.resume(null)
            return@suspendCancellableCoroutine
        }
        val main = Handler(Looper.getMainLooper())
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        var done = false
        fun finish(t: String?) {
            if (done) return
            done = true
            main.post { r.destroy() }
            if (cont.isActive) cont.resume(t)
        }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) { lastError = e; finish(null) }
            override fun onResults(b: Bundle?) {
                finish(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
            }
            override fun onPartialResults(b: Bundle?) {
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onPartial)
            }
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        cont.invokeOnCancellation { done = true; main.post { r.destroy() } }
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        )
    }
}
