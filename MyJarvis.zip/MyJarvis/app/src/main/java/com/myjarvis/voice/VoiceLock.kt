package com.myjarvis.voice

/** Only one thing may use the microphone: the wake-word service pauses while the app is listening. */
object VoiceLock {
    @Volatile var appListening = false
}
