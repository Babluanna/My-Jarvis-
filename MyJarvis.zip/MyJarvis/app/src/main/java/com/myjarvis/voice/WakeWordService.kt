package com.myjarvis.voice

import android.Manifest
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.myjarvis.JarvisApplication
import com.myjarvis.MainActivity
import com.myjarvis.R
import kotlinx.coroutines.*

/**
 * OPTIONAL "Hey Jarvis" listener. Runs only while the user has switched it on, always shows a
 * persistent notification, and stops when switched off. It uses Android's SpeechRecognizer in a loop
 * (simple and dependency-free). It is battery hungry; for production swap in an on-device wake-word
 * engine (e.g. Picovoice Porcupine) inside [loop].
 */
class WakeWordService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private lateinit var voice: VoiceInput

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return START_NOT_STICKY
        }
        val open = android.app.PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), android.app.PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, JarvisApplication.CH_WAKE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Jarvis is listening for “Hey Jarvis”")
            .setContentText("Turn this off any time in Settings.")
            .setOngoing(true).setContentIntent(open).build()
        ServiceCompat.startForeground(this, 42, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        voice = VoiceInput(this)
        if (job == null) job = scope.launch { loop() }
        return START_STICKY
    }

    private suspend fun loop() {
        while (currentCoroutineContext().isActive) {
            if (VoiceLock.appListening) { delay(1500); continue }
            val heard = voice.listen("en-IN") {}
            if (heard != null && matches(heard)) {
                // Works when the app is open/recent, or when "Display over other apps" is allowed.
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        .putExtra("start_voice", true)
                )
                delay(8000)
            } else {
                delay(if (voice.lastError == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 2000 else 400)
            }
        }
    }

    private fun matches(t: String): Boolean {
        val s = t.lowercase()
        return "jarvis" in s || "జార్విస్" in s || "जार्विस" in s || "जारविस" in s
    }

    override fun onDestroy() {
        job?.cancel(); scope.cancel(); super.onDestroy()
    }
}
