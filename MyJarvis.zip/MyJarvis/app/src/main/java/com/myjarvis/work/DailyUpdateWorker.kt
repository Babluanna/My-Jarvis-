package com.myjarvis.work

import android.content.Context
import androidx.work.*
import com.myjarvis.JarvisApplication
import java.time.Duration
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.util.concurrent.TimeUnit

/** Posts a short morning briefing (about 8:00) fetched from the backend. */
class DailyUpdateWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        val app = applicationContext as JarvisApplication
        val s = app.prefs.current()
        if (!s.daily) return Result.success()
        return try {
            val text = app.api.daily(s.language, OffsetDateTime.now().toString()).text
            Notifier.post(applicationContext, JarvisApplication.CH_DAILY, 7, "Your daily update", text)
            Result.success()
        } catch (e: Exception) {
            if (runAttemptCount < 3) Result.retry() else Result.success()
        }
    }

    companion object {
        fun schedule(ctx: Context, on: Boolean) {
            val wm = WorkManager.getInstance(ctx)
            if (!on) { wm.cancelUniqueWork("daily"); return }
            val now = LocalDateTime.now()
            var t = now.withHour(8).withMinute(0).withSecond(0).withNano(0)
            if (!t.isAfter(now)) t = t.plusDays(1)
            val req = PeriodicWorkRequestBuilder<DailyUpdateWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(Duration.between(now, t))
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            wm.enqueueUniquePeriodicWork("daily", ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}
