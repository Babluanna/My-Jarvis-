package com.myjarvis.work

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.myjarvis.JarvisApplication

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = (i.getLongExtra("id", 0L) % 100000).toInt() + 1000
        Notifier.post(c, JarvisApplication.CH_REMINDERS, id, "Reminder", i.getStringExtra("text") ?: "")
    }
}
